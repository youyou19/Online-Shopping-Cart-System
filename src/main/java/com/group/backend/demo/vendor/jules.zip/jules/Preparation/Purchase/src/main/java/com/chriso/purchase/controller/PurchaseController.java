package com.chriso.purchase.controller;

import com.chriso.purchase.intercomm.CustomerClient;
import com.chriso.purchase.intercomm.ProductClient;
import com.chriso.purchase.model.CustomerDTO;
import com.chriso.purchase.model.ProductDTO;
import com.chriso.purchase.model.Purchase;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/purchase")
public class PurchaseController {
    @Autowired
    private CustomerClient customerClient;

    @Autowired
    private ProductClient productClient;

    @GetMapping("/{purchaseID}/{productNumber}/{customerNumber}/{amount}")
    @HystrixCommand(fallbackMethod = "getFallback")
    public Purchase createPurchase(@PathVariable("purchaseID") int purchaseID,
                                   @PathVariable("productNumber") String productNumber,
                                   @PathVariable("customerNumber") String customerNumber,
                                   @PathVariable("amount") int amount){
        Purchase purchase = new Purchase();

        ProductDTO productDTO = productClient.getProduct(productNumber);
        CustomerDTO customerDTO = customerClient.getCustomer(customerNumber);
        if (productDTO!=null && customerDTO!=null){
            purchase.setAmount(amount);
            purchase.setCustomerNumber(customerDTO.getCustomerNumber());
            purchase.setProductNumber(productDTO.getProductNumber());
            purchase.setPurchaseID(purchaseID);
        }else {

            throw new RuntimeException();
        }



        return purchase;
    }


    public Purchase getFallback(int purchaseID,
                              String productNumber,
                              String customerNumber,
                              int amount) {
        Purchase purchase = new Purchase();
        purchase.setProductNumber("Product not exist");
        purchase.setCustomerNumber("Customer not exist");

        return purchase;
    }



}
