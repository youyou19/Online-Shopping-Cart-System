package com.chriso.customer.service;


import com.chriso.customer.model.Customer;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerService {
    private List<Customer> arrayList = new  ArrayList<>();
    
    
    public List<Customer> getCustomers(){
        arrayList.add(new Customer("cus1","peter"));
        arrayList.add(new Customer("cus2","jean"));
        arrayList.add(new Customer("cus3","chrisner"));
        arrayList.add(new Customer("cus4","joseph"));
        arrayList.add(new Customer("cus5","darimathe"));
       
        return arrayList;
    }
    
    
}
