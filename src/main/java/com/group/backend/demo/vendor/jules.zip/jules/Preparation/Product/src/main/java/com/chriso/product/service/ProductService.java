package com.chriso.product.service;

import com.chriso.product.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    private List<Product> products = new ArrayList<>();

    public List<Product> getProducts(){
        products.add(new Product("Prod1","Desk"));
        products.add(new Product("Prod2","Laptop"));
        products.add(new Product("Prod3","Computer Desktop"));
        products.add(new Product("Prod4","Cell Phone"));

        return  products;
    }
}
