package com.chriso.customer.controller;

import com.chriso.customer.model.Customer;
import com.chriso.customer.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("/{customerNumber}")
    @HystrixCommand(fallbackMethod = "getFallbackMethod")
    public Customer getCustomer(@PathVariable("customerNumber") String customerNumber) {
        Customer customer = customerService.getCustomers().stream()
                .filter(x -> x.getCustomerNumber().equalsIgnoreCase(customerNumber))
                .findAny()
                .orElse(null);

        if (customer.getCustomerNumber().equalsIgnoreCase("cus1")) {
            throw new RuntimeException();
        }

        return customer;
    }

    public Customer getFallbackMethod(String customerNumber) {

        Customer customer = new Customer();
        customer.setCustomerNumber("fallbackCustomerNumber");
        customer.setName("fallbackCustomerName");

        return customer;
    }

}
