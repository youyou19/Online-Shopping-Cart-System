package com.chriso.product.controller;

import com.chriso.product.model.Product;
import com.chriso.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getProducts() {

        return productService.getProducts();
    }

    @GetMapping("/{productNumber}")
    public Product getProduct(@PathVariable("productNumber") String productNumber) {
        return productService.getProducts().stream().filter(p -> p.getProductNumber().equals(productNumber)).findAny().orElse(null);
    }
}
