package com.chriso.purchase.intercomm;

import com.chriso.purchase.model.ProductDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient("Product-Service")
public interface ProductClient {
    @GetMapping("/product")
    public List<ProductDTO> getProducts();

    @GetMapping("/product/{productNumber}")
    public ProductDTO getProduct(@PathVariable("productNumber") String productNumber);

    }
