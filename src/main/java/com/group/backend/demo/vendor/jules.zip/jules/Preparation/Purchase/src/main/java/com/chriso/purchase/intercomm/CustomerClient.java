package com.chriso.purchase.intercomm;

import com.chriso.purchase.model.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("Customer-service")
public interface CustomerClient {

    @GetMapping("/customer/{customerNumber}")
    public CustomerDTO getCustomer(@PathVariable("customerNumber") String customerNumber) ;

    }
