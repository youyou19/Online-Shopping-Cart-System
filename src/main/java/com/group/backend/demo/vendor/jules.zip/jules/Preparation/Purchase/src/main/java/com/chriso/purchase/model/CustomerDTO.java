package com.chriso.purchase.model;

public class CustomerDTO {
    private String customerNumber;
    private String name;

    public CustomerDTO() { }

    public CustomerDTO(String customerNumber, String name) {
        this.customerNumber = customerNumber;
        this.name = name;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
