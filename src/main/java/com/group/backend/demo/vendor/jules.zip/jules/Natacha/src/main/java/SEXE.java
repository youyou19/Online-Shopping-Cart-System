public enum SEXE {
    male,femelle;
}
