import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {


    public static void main(String arg[]) {
       /* System.out.println(Main.IsDigit(11));
        System.out.println(Main.binaryPatternMatching("010", "amazing"));
      */
        /*System.out.println(Main.countPalindrome("tacocat"));
        System.out.println(Main.countPalindrome("aaa"));
        System.out.println(Main.countPalindrome("abccba"));
        System.out.println(Main.countPalindrome("daata"));*/

        solve(10, "bonjour christ");

        //System.out.println(revWordsInAGo("bonjoure chris"));
    }


    public static int IsDigit(int n) {
        int product = 1;
        int sum = 0;
        int temp = n;
        while (temp > 0) {
            int result = temp % 10;
            product *= result;
            sum += result;
            temp /= 10;
        }
        return product - sum;
    }


    public static int binaryPatternMatching(String pattern, String s) {
        int count = 0;

        for (int i = 0; i < s.length() - pattern.length() + 1; i++) {
            boolean match = true;
            String sub = s.substring(i, i + pattern.length());
            for (int j = 0; j < sub.toLowerCase().length(); j++) {
                if (((sub.charAt(j) == 'a' || sub.charAt(j) == 'e' || sub.charAt(j) == 'i'
                        || sub.charAt(j) == '0' ||
                        sub.charAt(j) == 'u' || sub.charAt(j) == 'y') && pattern.charAt(j) == '1')
                        || (sub.charAt(j) != 'a' && sub.charAt(j) != 'e' && sub.charAt(j) != 'i'
                        && sub.charAt(j) != 'o' &&
                        sub.charAt(j) != 'u' && sub.charAt(j) != 'y') && pattern.charAt(j) == '0') {
                    match = false;
                    break;
                }
            }
            if (match) count++;
        }

        return count;
    }

    public static int countPalindrome(String s) {
        int len = s.length();
        int temp = 0;
        String arr[] = new String[len * (len + 1) / 2];
        int count = 0;
        for (int i = 0; i < len; i++) {
            //This loop adds the next character every iteration for the subset to form and add it to the array
            for (int j = i; j < len; j++) {
                arr[temp] = s.substring(i, j + 1);
                temp++;
            }
        }

        for (int j = 0; j < arr.length; j++) {
            if (isPalindrome(arr[j])) count++;
        }

        return count;
    }


    private static boolean isPalindrome(String str) {
        if (str.length() == 0 || str.length() == 1) return true;

        if (str.charAt(0) == str.charAt(str.length() - 1))
            return isPalindrome(str.substring(1, str.length() - 1));

        return false;
}

     public static void solve(int n, String str){

        String result="";
        String word="";
        if (str==null) return;

        for (int i=0;i<n;i++){
            if (str.charAt(i)=='a'|| str.charAt(i)=='A'
                    || str.charAt(i)=='e' || str.charAt(i)=='E'
                    || str.charAt(i)=='i'|| str.charAt(i)=='I'
                    || str.charAt(i)=='o'|| str.charAt(i)=='O'
                    || str.charAt(i)=='u' || str.charAt(i)=='U'
                    || str.charAt(i)=='y'|| str.charAt(i)=='Y'
                    || str.charAt(i)==' '){
                result +=word;
                word="";
            } else {
                word = word + str.charAt(i) ;
            }

        }

        if (str.length()>n){
            result +=word + str.substring(n,str.length());
        }else {

            result += word;
        }
        System.out.println(result);



     }


    public static void solve1(int n, String str){

       String temp="";
       char[] chars=str.toCharArray();
       for (int i=0;i<n;i++){
           if (chars[i]=='o' || chars[i]=='O'
                   || chars[i]=='e' || chars[i]=='E'
                   || chars[i]=='i' || chars[i]=='I'
                   || chars[i]=='a' || chars[i]=='A'
                   || chars[i]=='u' || chars[i]=='U'
                   || chars[i]=='y' || chars[i]=='Y'
                   || chars[i]==' '
           ){
               chars[i]=' ';
           }

       }



    }


    public static String revWordsInAGo(String s) {
        if(s == null || s.length() == 1) return s;
        String r = "", w = "";
        char[] c = s.toCharArray();
        int i = 0;
        for(; i < c.length; i++) {
            char ch = c[i];
            if(ch == ' ') {
                r = r + w + ch;
                w = "";
            } else {
                w = ch + w;
            }
        }
        if(c[i - 1] != ' ') { // In case last character is not space
            r = r + w;
        }
        return r;
    }

}

