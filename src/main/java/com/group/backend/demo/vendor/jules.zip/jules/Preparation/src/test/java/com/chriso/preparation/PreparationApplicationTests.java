package com.chriso.preparation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreparationApplicationTests {

	@Test
	void contextLoads() {
	}

}
