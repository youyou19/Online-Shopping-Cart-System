package com.chriso.account.model;

public class Account {
    private String accountNumber;
    private String accountType;
    private String customerNumber;
    private double amount;


    public Account() {
    }

    public Account(String accountNumber, String accountType, String customerNumber, double amount) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.customerNumber = customerNumber;
        this.amount = amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
