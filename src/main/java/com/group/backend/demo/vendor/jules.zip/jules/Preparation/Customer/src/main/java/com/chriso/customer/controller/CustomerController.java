package com.chriso.customer.controller;

import com.chriso.customer.model.Customer;
import com.chriso.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("/{customerNumber}")
    public Customer getCustomer(@PathVariable("customerNumber") String customerNumber) {
        return customerService.getCustomers().stream()
                .filter(x -> x.getCustomerNumber().equalsIgnoreCase(customerNumber))
                .findAny()
                .orElse(null);



    }



}
