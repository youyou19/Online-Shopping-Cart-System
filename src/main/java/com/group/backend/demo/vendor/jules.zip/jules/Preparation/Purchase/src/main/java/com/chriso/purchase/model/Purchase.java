package com.chriso.purchase.model;

public class Purchase {
    private int purchaseID;
    private String productNumber;
    private String customerNumber;
    private int amount;

    public Purchase() {
    }

    public Purchase(int purchaseID, String productNumber, String customerNumber, int amount) {
        this.purchaseID = purchaseID;
        this.productNumber = productNumber;
        this.customerNumber = customerNumber;
        this.amount = amount;
    }

    public int getPurchaseID() {
        return purchaseID;
    }

    public void setPurchaseID(int purchaseID) {
        this.purchaseID = purchaseID;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
