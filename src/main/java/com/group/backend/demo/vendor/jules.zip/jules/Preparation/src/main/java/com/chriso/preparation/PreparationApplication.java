package com.chriso.preparation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreparationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreparationApplication.class, args);
	}

}
