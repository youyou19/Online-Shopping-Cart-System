package com.chriso.purchase.model;

import java.util.ArrayList;
import java.util.List;

public class ProductList {
    private List<ProductDTO> productDTOS = new ArrayList<>();

    public List<ProductDTO> getProductDTOS() {
        return productDTOS;
    }

    public void setProductDTOS(List<ProductDTO> productDTOS) {
        this.productDTOS = productDTOS;
    }
}
