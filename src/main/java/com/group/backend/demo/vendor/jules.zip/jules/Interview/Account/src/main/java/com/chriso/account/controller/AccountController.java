package com.chriso.account.controller;

import com.chriso.account.model.Account;
import com.chriso.account.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/{customerNumber}")
    public Account get(@PathVariable("customerNumber") String customerNumber){
        String urlBase ="http://Customer-service/customer/" + customerNumber;
        Account account=new Account();
        Customer customer = restTemplate.getForObject(urlBase,Customer.class);
        if (customer!=null){
            account.setAccountNumber("acc1");
            account.setAccountType("checking");
            account.setAmount(4000);
            account.setCustomerNumber(customer.getCustomerNumber());
        }

        return account;
    }

}
