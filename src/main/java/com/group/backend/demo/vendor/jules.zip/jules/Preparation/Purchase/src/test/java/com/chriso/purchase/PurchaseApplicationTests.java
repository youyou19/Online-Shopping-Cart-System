package com.chriso.purchase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurchaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
