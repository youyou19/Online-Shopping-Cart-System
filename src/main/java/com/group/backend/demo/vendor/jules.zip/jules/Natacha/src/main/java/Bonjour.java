import java.util.Scanner;

public class Bonjour {







    public static void main(String arg[]){

        int number1;
        int number2;

        Scanner sc= new Scanner(System.in);

        System.out.println("Saisir le premier nombre: ");
        number1 = sc.nextInt();

        System.out.println("Saisir le second nombre: ");
        number2 = sc.nextInt();

      if (number1>number2){
         System.out.println(number1);
      }else if (number2>number1){
          System.out.println(number2);

      } else {

          System.out.println("Les deux nombre sont egaux");
      }



    }
}
